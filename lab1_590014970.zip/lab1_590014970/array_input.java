public class array_input {
    
    int x = 50;

    public static void main(String[] args) {
        array_input obj=new array_input();

        System.out.println("Value of x= " + obj.x);
    }
}
    

