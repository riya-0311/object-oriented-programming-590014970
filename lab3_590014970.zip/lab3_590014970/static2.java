import java.util.Scanner;
public class static2 {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int n;
        n = s.nextInt();
        System.out.println(n);
    }
    
}
